<button id="cart-btn">Add to Cart</button>


    // Obtém uma referência ao botão usando o ID "cart-btn"
    var cartButton = document.getElementById("cart-btn");

    // Adiciona um ouvinte de evento ao botão
    cartButton.addEventListener("click", function() {
        // Exibe a mensagem quando o botão é clicado
        alert("Produto adicionado ao carrinho!");
    });

